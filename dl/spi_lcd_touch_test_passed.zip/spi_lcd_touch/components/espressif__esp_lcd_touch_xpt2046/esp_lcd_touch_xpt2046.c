/*
 * SPDX-FileCopyrightText: 2015-2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/gpio.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_touch.h"
#include <math.h>

static const char *TAG = "xpt2046";

#define CMD_READ_X 0X90
#define CMD_READ_Y 0XD0
#define XY_RAWERR   5
#define TOUCH_XMIN  190
#define TOUCH_XMAX  1935
#define TOUCH_YMIN  125
#define TOUCH_YMAX  1860
#define LCD_XMAX    320
#define LCD_YMAX    240

#define X_RELEASE_VALUE 2047
#define Y_RELEASE_VALUE 0

/*******************************************************************************
* Function definitions
*******************************************************************************/
static bool esp_lcd_touch_xpt2046_get_xy(esp_lcd_touch_handle_t tp, uint16_t *x, uint16_t *y, uint16_t *strength, uint8_t *point_num, uint8_t max_point_num);

/*******************************************************************************
* Public API functions
*******************************************************************************/

esp_err_t esp_lcd_touch_new_spi_xpt2046(const esp_lcd_panel_io_handle_t io, const esp_lcd_touch_config_t *config, esp_lcd_touch_handle_t *out_touch)
{
    esp_err_t ret = ESP_OK;

    assert(io != NULL);
    assert(config != NULL);
    assert(out_touch != NULL);

    /* Prepare main structure */
    esp_lcd_touch_handle_t esp_lcd_touch_xpt2046 = heap_caps_calloc(1, sizeof(esp_lcd_touch_t), MALLOC_CAP_DEFAULT);
    ESP_GOTO_ON_FALSE(esp_lcd_touch_xpt2046, ESP_ERR_NO_MEM, err, TAG, "no mem for xpt2046 controller");

    /* Communication interface */
    esp_lcd_touch_xpt2046->io = io;

    /* Only supported callbacks are set */
    esp_lcd_touch_xpt2046->get_xy = esp_lcd_touch_xpt2046_get_xy;

    /* Mutex */
    esp_lcd_touch_xpt2046->data.lock.owner = portMUX_FREE_VAL;

    /* Save config */
    memcpy(&esp_lcd_touch_xpt2046->config, config, sizeof(esp_lcd_touch_config_t));

    /* Prepare pin for touch interrupt */
    if (esp_lcd_touch_xpt2046->config.int_gpio_num != GPIO_NUM_NC) {
        const gpio_config_t int_gpio_config = {
            .mode = GPIO_MODE_INPUT,
            .intr_type = GPIO_INTR_NEGEDGE,
            .pin_bit_mask = BIT64(esp_lcd_touch_xpt2046->config.int_gpio_num)
        };
        ret = gpio_config(&int_gpio_config);
        ESP_GOTO_ON_ERROR(ret, err, TAG, "GPIO config failed");

        /* Register interrupt callback */
        if (esp_lcd_touch_xpt2046->config.interrupt_callback) {
            esp_lcd_touch_register_interrupt_callback(esp_lcd_touch_xpt2046, esp_lcd_touch_xpt2046->config.interrupt_callback);
        }
    }

err:
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Error (0x%x)! Touch controller xpt2046 initialization failed!", ret);
       
    }

    *out_touch = esp_lcd_touch_xpt2046;

    return ret;
}

static int cal_average(int numbers[], int length) {
    int i, j, temp;
    float average, sum = 0;

    // 冒泡排序
    for (i = 0; i < (length - 1); i++) {
        for (j = 0; j < 4 - i; j++) {
            if (numbers[j] > numbers[j + 1]) {
                temp = numbers[j];
                numbers[j] = numbers[j + 1];
                numbers[j + 1] = temp;
            }
        }
    }

    // 去掉最小和最大值
    for (i = 1; i < (length-1); i++) {
        sum += numbers[i];
    }

    // 计算平均值
    average = sum / (length-2);

    // 输出结果
    return average;
}

static esp_err_t touch_xpt2046_read(esp_lcd_touch_handle_t tp, uint8_t cmd, uint8_t *data, uint8_t len)
{
    assert(tp != NULL);
    assert(data != NULL);
    esp_err_t ret, res = ESP_OK;
    #define NUM_FILTER 5
    int numbers[NUM_FILTER];
    for (int i = 0; i < NUM_FILTER; i++) {
        ret = esp_lcd_panel_io_rx_param(tp->io, cmd, data, len);
        if (ret != ESP_OK) {
            res = ret;
            ESP_LOGI(TAG, "touch_xpt2046_read  ret = %d", ret);
        }
        numbers[i] = (data[0]<<8) | data[1];
        data[0] = 0;
        data[1] = 0;
    }
    int cal_ret = cal_average(numbers, NUM_FILTER);
    data[0] = cal_ret >> 8;
    data[1] = cal_ret & 0xff;
    return res;
}

static bool esp_lcd_touch_xpt2046_get_xy(esp_lcd_touch_handle_t tp, uint16_t *x, uint16_t *y, uint16_t *strength, uint8_t *point_num, uint8_t max_point_num)
{
    assert(tp != NULL);
    assert(x != NULL);
    assert(y != NULL);
    assert(point_num != NULL);
    assert(max_point_num > 0);
    static int count = 0;
    bool err = false;
    int x1 = 0, y1 = 0, x_cor = 0, y_cor = 0, pressed_temp = 0;
    bool pressed = false;
    esp_err_t ret = ESP_OK;

    uint8_t data[2] = {0};
    /* Count of points */
    *point_num = max_point_num;
    //读坐标 赋值
    for (size_t i = 0; i < *point_num; i++) {
        //读取x坐标
        ret = touch_xpt2046_read(tp, CMD_READ_X, data, 2);
        if (ret != ESP_OK) {
            err = true;
        }
        x1 =  ((data[0]<<8) | data[1]) >> 4;
        ret = touch_xpt2046_read(tp, CMD_READ_Y, data, 2);
        if (ret != ESP_OK) {
            err = true;
        }
        y1 =  ((data[0]<<8) | data[1]) >> 4;
        if (abs(X_RELEASE_VALUE-x1) > XY_RAWERR && abs(y1 - Y_RELEASE_VALUE) > XY_RAWERR) {
            pressed = true;
        }
        #if 0
         ESP_LOGI(TAG, "esp_lcd_touch_xpt2046_get_xy x1: %d ,TOUCH_XMIN: %d, LCD_XMAX: %d, TOUCH_XMAX: %d, abs(x1 - TOUCH_XMIN): %d, TOUCH_XMAX - TOUCH_XMIN: %d x[i]: %d", \
         x1, TOUCH_XMIN, LCD_XMAX, TOUCH_XMAX, abs(x1 - TOUCH_XMIN), TOUCH_XMAX - TOUCH_XMIN, (abs(x1 - TOUCH_XMIN) * LCD_XMAX / (TOUCH_XMAX - TOUCH_XMIN)));
        #endif
        y_cor = abs(x1 - TOUCH_XMIN) * LCD_XMAX / (TOUCH_XMAX - TOUCH_XMIN);
        //读取y坐标
        x_cor = (abs(y1 - TOUCH_YMIN) * LCD_YMAX / (TOUCH_YMAX - TOUCH_YMIN));
        if (y_cor > LCD_XMAX) {
            y_cor = LCD_XMAX;
        } else if (y_cor < 0) {
            y_cor = 0;
        }
        y_cor = LCD_XMAX - y_cor;
        
        x[i] = (uint16_t)x_cor;
        y[i] = (uint16_t)y_cor;

        if (strength) {
            strength[i] = tp->data.coords[i].strength;
        }
        pressed_temp = pressed;
    }
    /* Invalidate */
    tp->data.points = 0;
    count++;
    if (count > 5) {
        count = 0;
        ESP_LOGI(TAG, "esp_lcd_touch_xpt2046_get_xy LVGL task: x: %d y: %d, x_cor: %d , y_cor: %d, pressed_temp: %d, err: %d", (int)x1, (int)y1, x_cor, y_cor, pressed_temp, (int)err);
    }
    return pressed;
}

esp_err_t esp_lcd_touch_xpt2046_del(esp_lcd_touch_handle_t tp)
{
    assert(tp != NULL);

    /* Reset GPIO pin settings */
    if (tp->config.int_gpio_num != GPIO_NUM_NC) {
        gpio_reset_pin(tp->config.int_gpio_num);
    }

    /* Reset GPIO pin settings */
    if (tp->config.rst_gpio_num != GPIO_NUM_NC) {
        gpio_reset_pin(tp->config.rst_gpio_num);
    }

    free(tp);

    return ESP_OK;
}
